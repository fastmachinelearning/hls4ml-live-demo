from pynq import DefaultHierarchy, DefaultIP
from pynq import Overlay



class HDMI(Overlay):
    def __init__(self, bitfile_name,download=True):
        super().__init__(bitfile_name, download=True)
